%%%% Team 8 
Va = 100 ; % Armature Input Voltage
Ra = 0.4 ; % Armature Resistance
La = 0.4 ; % Armature Inductance
B = 0.02 ; % Damping Coefficient (Due Friction)
J = 7    ; % Motor Body Inertia (J = m.r^2)
Tl = 30  ; % Load Torque 
K = 1.4  ; % constant